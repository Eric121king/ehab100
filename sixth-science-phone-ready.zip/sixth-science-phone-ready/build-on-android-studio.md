1. Open this folder in Android Studio.
2. Let Gradle sync using the network.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be in app/build/outputs/apk/debug/.
